public void moveZeroes(int[] nums) {
    int i = 0; // pointer for non-zero elements
    
    // Traverse the array
    for (int j = 0; j < nums.length; j++) {
        if (nums[j] != 0) {
            // Swap non-zero element with the element at the current pointer
            int temp = nums[i];
            nums[i] = nums[j];
            nums[j] = temp;
            
            // Increment the non-zero pointer
            i++;
        }
    }
}
